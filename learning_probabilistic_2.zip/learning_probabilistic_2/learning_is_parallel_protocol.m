function learning_is_parallel_protocol(C,d,k)
% Code that imposes SPD constrains on a variable C to enforce that C is a valid
% parallel storing learning network
% 'C' corresponds to the Choi operator of the network
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)

%  Important: To write the equality constraints of the Choi operator of the
%  quantum network, we need to make sure the systems for the left hand side
%  and the right hand side coulping in the same order.

    cvx_begin SDP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
     % Storing network has 2 slots with {input,output} pair {1,2},{3,4}, 
     % the target operation has {input,output} {5,6}
     PartialTrace(C,6,[d d d d d d]) == PermuteSystems(kron(PartialTrace(C,[2 4 5 6],[d d d d d d]),eye(d^3)/(d^3)), [1 3 2 4 5]); 
     % Tr_6[C] = Tr_{2456}[C] \otimes I_245
     % Change order: 13245 -> 12345
     trace(C) == 8;
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3
    % Storing network has 3 slots with {input,output} pair {1,2},{3,4},{5,6} 
    % the target operation has {input,output} {7,8}
    PartialTrace(C,8, [d d d d d d d d]) == PermuteSystems(kron(PartialTrace(C,[2 4 6 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 4 2 5 3 6 7]);
    % Tr_8[C] = Tr_{24678}[C] \otimes I_2467
    % Change order: 1352467 -> 1234567
    trace(C) == 16;     
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
if k==4  
    % Storing network has 4 slots with {input,output} pair
    % {1,2},{3,4},{5,6},{7,8}, the target operation has {input,output} {9,10}
    PartialTrace(C,10, [d d d d d d d d d d]) == PermuteSystems(kron(PartialTrace(C,[2 4 6 8 9 10], [d d d d d d d d d d]),eye(d^5)/(d^5)), [1 5 2 6 3 7 4 8 9]);
    % Tr_{10}[C] = Tr_{2468910}[C] \otimes I_24689
    % Change order: 135724689 -> 123456789
    trace(C) == 32;     
end %end if k==4
    cvx_end
end
