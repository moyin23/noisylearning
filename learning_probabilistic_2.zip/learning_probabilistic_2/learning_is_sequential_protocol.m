function learning_is_sequential_protocol(C,d,k)
% Code that imposes SPD constrains on a variable C to enforce that C is a valid
% sequential storing learning network
% 'C' corresponds to the Choi operator of the network
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)

%  Important: To write the equality constraints of the Choi operator of the
%  quantum network, we need to make sure the systems for the left hand side
%  and the right hand side coulping in the same order.

    cvx_begin SDP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
     % Storing network has 2 slots with {input,output} pair {1,2},{3,4}, 
     % the target operation has {input,output} {5,6}
     PartialTrace(C,6,[d d d d d d]) == kron(PartialTrace(C,[4 5 6],[d d d d d d]),eye(d^2)/(d^2));
     % Tr_6[C] = Tr_{456}[C] \otimes I_45
     PartialTrace(C,[3 4 5 6],[d d d d d d]) == kron(PartialTrace(C,[2 3 4 5 6],[d d d d d d]),eye(d)/d);
     % Tr_{3456}[C] = Tr_{23456}[C] \otimes I_3
     trace(C) == 8;
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3  
    % Storing network has 3 slots with {input,output} pair {1,2},{3,4},{5,6} 
    % the target operation has {input,output} {7,8}
    PartialTrace(C,8, [d d d d d d d d]) == kron(PartialTrace(C,[6 7 8], [d d d d d d d d]),eye(d^2)/(d^2));
    % Tr_8[C] = Tr_{678}[C] \otimes I_67
    PartialTrace(C,[5 6 7 8], [d d d d d d d d]) == kron(PartialTrace(C,[4 5 6 7 8], [d d d d d d d d]),eye(d)/d);
    % Tr_{5678}[C] = Tr_{45678}[C] \otimes I_4
    PartialTrace(C,[3 4 5 6 7 8], [d d d d d d d d]) == kron(PartialTrace(C,[2 3 4 5 6 7 8], [d d d d d d d d]),eye(d)/d);
    % Tr_{345678}[C] = Tr_{2345678}[C] \otimes I_2
    trace(C) == 16;     
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
if k==4  
    % Storing network has 4 slots with {input,output} pair
    % {1,2},{3,4},{5,6},{7,8}, the target operation has {input,output} {9,10}
    PartialTrace(C,10, [d d d d d d d d d d]) == kron(PartialTrace(C,[8 9 10], [d d d d d d d d d d]),eye(d^2)/(d^2));
    % Tr_10[C] = Tr_{8910}[C] \otimes I_89
    PartialTrace(C,[7 8 9 10], [d d d d d d d d d d]) == kron(PartialTrace(C,[6 7 8 9 10], [d d d d d d d d d d]),eye(d)/d);
    % Tr_{78910}[C] = Tr_{678910}[C] \otimes I_6
    PartialTrace(C,[5 6 7 8 9 10], [d d d d d d d d d d]) == kron(PartialTrace(C,[4 5 6 7 8 9 10], [d d d d d d d d d d]),eye(d)/d);
    % Tr_{5678910}[C] = Tr_{45678910}[C] \otimes I_4
    PartialTrace(C,[3 4 5 6 7 8 9 10], [d d d d d d d d d d]) == kron(PartialTrace(C,[2 3 4 5 6 7 8 9 10], [d d d d d d d d d d]),eye(d)/d);
    % Tr_{345678910}[C] = Tr_{2345678910}[C] \otimes I_2
    trace(C) == 32;     
end %end if k==4
    cvx_end
end
