% This gives the optimal probability to learn gate 'U' using 'k' learning gates and only 'g' of them are good
% The other gates are not completely depolarizing channnels.
%       pnoisy * ND + (1-pnoisy) * U

                d=2               %Dimension 'd'
                k=3               %Number of uses 'k'
                g=2               %Number of good unitaries
                n=0;              %Number of linear independent U_d^k, n==0 implies full basis
                chose_protocol=1; %1 for parallel, 2 for sequential, 3 for general
                isComplex=1;      %Set isComples=0 to restric to supermaps with real coefficients
                pnoise = 0.1;       %completely depolorizing channel: pnoise =1; U: pnoise = 0


if n==0
% Set 'n' as the dimension of the space spanned by k d-dimensional unitary
% channels
    n=find_dimension(d,k)
else
    % 'The dimension of the space spanned by k d-dimensional channels is:'
    n=n
    dim_k_d_unitaries=find_dimension(d,k)
        if dim_k_d_unitaries>n
            'The dimension of the space spanned by U_d^k is smaller than the number of unitaries n'
            'The value pmax that will be displayed is just an upper bound'
        end
end
%Create a maximally entangled state and multiply by the dimension 'd'
    max_ent_times_d=IsotropicState(d,1)*d+0;
%Declare variables that contain the Choi input and Choi output operations
    Jin=zeros(d^2,d^2,n);  
    Jout=zeros(d^2,d^2,n);
    list_U=zeros(d,d,n);
%Asign values for Choi inputs and Choi outputs
for i=1:n 
    %Creates a d-dimensional random unitary, sampled by the Haar measure
        list_U(:,:,i)=RandomUnitary(d);
        U=list_U(:,:,i);
    %Creates the Choi operator for the unitary U and stock at a tensor for
    %the input
        Jin(:,:,i)=kron(U,eye(d)) * max_ent_times_d * kron(U',eye(d));
    %Define the Target unitary as 'U'
        Ut=U;
    %Creates the Choi operator for the target unitary U and stock at a tensor
    %for the output
        Jout(:,:,i)=kron(Ut,eye(d)) * max_ent_times_d * kron(Ut',eye(d));
end
tic;
% Find the maximal success probability of learning unitary U from 
% 'k' learning samples, with 'g' noisy gates (pnoisy)
if chose_protocol==1
    [maxp S F]=learning_maxp_parallel(Jin,Jout,k,g,d,isComplex,pnoise); %Assuming a parallel protocol
end
if chose_protocol==2
    [maxp S F]=learning_maxp_sequential(Jin,Jout,k,g,d,isComplex,pnoise);    %Assuming a sequential protocol
end
if chose_protocol==3
    [maxp S F]=learning_maxp_general(Jin,Jout,k,g,d,isComplex,pnoise);  %Assuming a geleral protocol
end
    maximal_success_probability=maxp
    total_time_in_minutes=toc/60
                