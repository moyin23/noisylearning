function [maxf D] = learning_maxf_general_dual(k,g,d,isComplex)
% Code that find the maximal fidelity of learning unitary U from
% noisy learning samples with a 'general' storing
% 'k' corresponds to the total number of the learning gates
% 'g' corresponds to how many good gates are used
% 'd' corresponds to SU(d)
% if isComplex is '0', the code only consider supermaps with real numbers
% is isComples is '1', the code considers general supermaps with complex
% numbers

Omega = learning_omega(k,g,d);  %  Get the performance operator

'GENERAL PROTOCOL'
    cvx_begin SDP
    %cvx_solver mosek
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
    variable lambda
   % Declare the SDP variables related to D
    if isComplex==1
        variable D(d^6,d^6) complex semidefinite
    else
        variable D(d^6,d^6) semidefinite
    end
    maximise lambda  % get the optimal performance
    D >= lambda * Omega;
    learning_is_general_protocol_dual(D,d,k);  % make sure D is the dual of a general learning network
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3
    variable lambda
    % Declare the SDP variables related to D
    if isComplex==1
        variable D(d^8,d^8) complex semidefinite
    else
        variable D(d^8,d^8) semidefinite
    end
    maximise lambda  % get the optimal performance
    D >= lambda * Omega;
    learning_is_general_protocol_dual(D,d,k);  % make sure D is the dual of a general learning network
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
if k==4
    variable lambda
   % Declare the SDP variables related to D
    if isComplex==1
        variable D(d^10,d^10) complex semidefinite
    else
        variable D(d^10,d^10) semidefinite
    end
    maximise lambda  % get the optimal performance
    D >= lambda * Omega;
    learning_is_general_protocol_dual(D,d,k);  % make sure D is the dual of a general learning network
end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%
%finish SDP
    cvx_end
    maxf=1/lambda;
    D=D;
end