% This gives the optimal fidelity to learn gate 'U' using 'k' learning gates and only 'g' of them are good
% The noisy gates are completely depolarizing channnels.
% An upper bound if provided by dual feasible solution.

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%  Start of Adjustable Parameters  %%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                d=2               %Dimension 'd' % This program only works for d=2 now.
                k=3               %Number of uses 'k'
                g=2               %Number of good unitaries
                chose_protocol=3; %1 for parallel, 2 for sequential, 3 for general
                isComplex=0;      %Set isComples=0 to restric to supermaps with real coefficients
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%   End of Adjustable Parameters   %%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
% Generate the performance operator
Omega = learning_omega(k,g,d);
% Find the maximal fidelity of learning unitary U from 
% 'k' learning samples, with 'g' noisy gates
if chose_protocol==1
    [maxf D]=learning_maxf_parallel_dual(k,g,d,isComplex);  %Assuming a parallel protocol
    D_fea = learning_changetodualfeasible_parallel(D,d,k);  % Make D dual feasible
    upperbound_parallel = learning_maxf_dual_feasible(Omega, D_fea)  % Get an upper bound from dual problem
end
if chose_protocol==2
    [maxf D]=learning_maxf_sequential_dual(k,g,d,isComplex);  %Assuming a sequential protocol
    D_fea = learning_changetodualfeasible_sequential(D,d,k);  % Make D dual feasible
    upperbound_sequential = learning_maxf_dual_feasible(Omega, D_fea)  % Get an upper bound from dual problem
end
if chose_protocol==3
    [maxf D]=learning_maxf_general_dual(k,g,d,isComplex);  %Assuming a general protocol
    D_fea = learning_changetodualfeasible_general(D,d,k);  % Make D dual feasible
    upperbound_general = learning_maxf_dual_feasible(Omega, D_fea)  % Get an upper bound from dual problem
end
    %maximal_fidelity=maxf;
    total_time_in_minutes=toc/60