function D_fea = learning_changetodualfeasible_sequential(D,d,k)
% Code that generate the dual operator 'D_fea' of a strictly feasible sequential
% learning network close to 'D'
% 'D' is the input dual operator
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)


% 1. Construct the non-floating-point matrix 'D_frac' by truncating
% the matrix 'D':
% keeping eight decimal digits, and then change to integer
    D_frac = learning_cut8(D);
% 2. Obtain a Hermition matrix
    D_Herm = (D_frac + D_frac')/2;
% 3. Project to the parallel learning network space:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
    if k == 2
    % D = D6
    % Corresponding projector: P(D) = D6
        D6 = kron(PartialTrace(D_Herm,6, [d d d d d d]), eye(d)/d);
        D_P = D6;
    % D456 = D3456
    % Corresponding projector: P(D) = D - D456 + D3456
        D456 = kron(PartialTrace(D_P, [4 5 6], [d d d d d d]), eye(d^3)/(d^3));
        D3456 = kron(PartialTrace(D_P, [3 4 5 6], [d d d d d d]), eye(d^4)/(d^4));
        D_P = D_P - D456 + D3456;
    % D23456 = D123456    
    % Corresponding projector: P(D) = D - D23456 + D123456
        D23456 = kron(PartialTrace(D_P, [2 3 4 5 6], [d d d d d d]), eye(d^5)/(d^5));
        D123456 = trace(D_P) * eye(d^6)/(d^6);
        D_P = D_P - D23456 + D123456;
    end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
    if k==3
    % D = D8
    % Corresponding projector: P(D) = D8
        D8 = kron(PartialTrace(D_Herm,8, [d d d d d d d d]), eye(d)/d);
        D_P = D8;
    % D678 = D5678
    % Corresponding projector: P(D) = D - D678 + D5678
        D678 = kron(PartialTrace(D_P, [6 7 8], [d d d d d d d d]), eye(d^3)/(d^3));
        D5678 = kron(PartialTrace(D_P, [5 6 7 8], [d d d d d d d d]), eye(d^4)/(d^4));
        D_P = D_P - D678 + D5678;
    % D45678 = D345678
    % Corresponding projector: P(D) = D - D45678 + D345678
        D45678 = kron(PartialTrace(D_P, [4 5 6 7 8], [d d d d d d d d]), eye(d^5)/(d^5));
        D345678 = kron(PartialTrace(D_P, [3 4 5 6 7 8], [d d d d d d d d]), eye(d^6)/(d^6));
        D_P = D_P - D45678 + D345678;
    % D2345678 = D12345678    
    % Corresponding projector: P(D) = D - D2345678 + D12345678
        D2345678 = kron(PartialTrace(D_P, [2 3 4 5 6 7 8], [d d d d d d d d]), eye(d^7)/(d^7));
        D12345678 = trace(D_P) * eye(d^8)/(d^8);
        D_P = D_P - D2345678 + D12345678;
    end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
    if k==4
    % D = D10
    % Corresponding projector: P(D) = D10
        D10 = kron(PartialTrace(D_Herm,10, [d d d d d d d d d d]), eye(d)/d);
        D_P = D10;
    % D8910 = D78910
    % Corresponding projector: P(D) = D - D8910 + D78910
        D8910 = kron(PartialTrace(D_P, [8 9 10], [d d d d d d d d d d]), eye(d^3)/(d^3));
        D78910 = kron(PartialTrace(D_P, [7 8 9 10], [d d d d d d d d d d]), eye(d^4)/(d^4));
        D_P = D_P - D8910 + D78910;
    % D678910 = D5678910
    % Corresponding projector: P(D) = D - D678910 + D5678910
        D678910 = kron(PartialTrace(D_P, [6 7 8 9 10], [d d d d d d d d d d]), eye(d^5)/(d^5));
        D5678910 = kron(PartialTrace(D_P, [5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^6)/(d^6));
        D_P = D_P - D678910 + D5678910;
    % D45678910 = D345678910
    % Corresponding projector: P(D) = D - D45678910 + D345678910
        D45678910 = kron(PartialTrace(D_P, [4 5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^7)/(d^7));
        D345678910 = kron(PartialTrace(D_P, [3 4 5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^8)/(d^8));
        D_P = D_P - D45678910 + D345678910;
    % D2345678910 = D12345678910    
    % Corresponding projector: P(D) = D - D2345678910 + D12345678910
        D2345678910 = kron(PartialTrace(D_P, [2 3 4 5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^9)/(d^9));
        D12345678910 = trace(D_P) * eye(d^10)/(d^10);
        D_P = D_P - D2345678910 + D12345678910;
    end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%

% 4. Add 'I' to make sure positivity
    eigenvalue = eigs(D_P,(d^(2*k+2)));
    mineig = min(eigenvalue);
    D_P = D_P + ceil(abs(mineig)) * eye(d^(2*k+2));

% 5. Normalization
    tracenow = trace(D_P);
    D_fea = D_P * d^(k+1) / tracenow;  % Tr[D] = d^(k+1)



