function learning_is_general_protocol_dual(D,d,k)
% Code that imposes SPD constrains on a variable D to enforce that D is a
% valid dual operator of a general learning network
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)

%  Important: To write the equality constraints of the Choi operator of the
%  quantum network, we need to make sure the systems for the left hand side
%  and the right hand side coulping in the same order.

% Note: for k = 4, hasn't been finished.

    cvx_begin SDP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
     % Declare the SDP variables corresponding to the encoders with memory
     % D = D6
     D == kron(PartialTrace(D,6,[d d d d d d]), eye(d)/d);
     
     % Denote: E = Tr_{56}[D] / d
     % Denote: D3to4 = Tr_{12}[E] / d
     % Denote: D1to2 = Tr_{34}[E] / d
     E = PartialTrace(D, [5 6], [d d d d d d]) /d;
     D3to4 = PartialTrace(E, [1 2], [d d d d]) /d;
     D1to2 = PartialTrace(E, [3 4], [d d d d]) /d;
     
     % Tr_{2}[E] = I1 \otimes D3to4
     PartialTrace(E, [2], [d d d d]) == kron(eye(d), D3to4);
     % D3to4 is a channel from 3 to 4: Tr_{4}[D3to4] = I3
     PartialTrace(D3to4, [2], [d d]) == eye(d);
     
     % Tr_{4}[E] = I3 \otimes D1to2
     PartialTrace(E, [4], [d d d d]) == kron(D1to2, eye(d));
     % D1to2 is a channel from 1 to 2: Tr_{2}[D1to2] = I1
     PartialTrace(D1to2, [2], [d d]) == eye(d);
     
     % Tr_{2,4}[E] = I13
     PartialTrace(E, [2 4], [d d d d]) == eye(d^2);
     
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3
     % Declare the SDP variables corresponding to the encoders with memory
     % D = D8
     D == kron(PartialTrace(D,8,[d d d d d d d d]), eye(d)/d);
     
     % Denote: E = Tr_{78}[D] / d
     % Denote: D35to46 = Tr_{12}[E] / d
     % Denote: D15to26 = Tr_{34}[E] / d
     % Denote: D13to24 = Tr_{56}[E] / d
     % Denote: D5to6 = Tr_{1234}[E] / d^2
     % Denote: D3to4 = Tr_{1256}[E] / d^2
     % Denote: D1to2 = Tr_{3456}[E] / d^2
     E = PartialTrace(D, [7 8], [d d d d d d d d]) /d;
     D35to46 = PartialTrace(E, [1 2], [d d d d d d]) /d;
     D15to26 = PartialTrace(E, [3 4], [d d d d d d]) /d;
     D13to24 = PartialTrace(E, [5 6], [d d d d d d]) /d;
     D5to6 = PartialTrace(E, [1 2 3 4], [d d d d d d]) /(d^2);
     D3to4 = PartialTrace(E, [1 2 5 6], [d d d d d d]) /(d^2);
     D1to2 = PartialTrace(E, [3 4 5 6], [d d d d d d]) /(d^2);

     % Tr_{2}[E] = I1 \otimes D35to46
     PartialTrace(E, [2], [d d d d d d]) == kron(eye(d), D35to46);
     % D35to46 is a channel from 35 to 46: Tr_{46}[D35to46] = I35
     PartialTrace(D35to46, [2 4], [d d d d]) == eye(d^2);
     
     % Tr_{4}[E] = I3 \otimes D15to26
     % change order: 31256 -> 12356
     PartialTrace(E, [4], [d d d d d d]) == PermuteSystems(kron(eye(d), D15to26), [2 3 1 4 5]);
     % D15to26 is a channel from 15 to 26: Tr_{26}[D15to26] = I15
     PartialTrace(D15to26, [2 4], [d d d d]) == eye(d^2);
     
     % Tr_{6}[E] = I5 \otimes D13to24
     PartialTrace(E, [6], [d d d d d d]) == kron(D13to24, eye(d));
     % D13to24 is a channel from 13 to 24: Tr_{24}[D13to24] = I13
     PartialTrace(D13to24, [2 4], [d d d d]) == eye(d^2);
     
     % Tr_{24}[E] = I13 \otimes D5to6
     PartialTrace(E, [2 4], [d d d d d d]) == kron(eye(d^2), D5to6);
     % D5to6 is a channel from 5 to 6: Tr_{6}[D5to6] = I5
     PartialTrace(D5to6, [2], [d d]) == eye(d);
     
     % Tr_{26}[E] = I15 \otimes D3to4
     % change order: 1534 -> 1345
     PartialTrace(E, [2 6], [d d d d d d]) == PermuteSystems(kron(eye(d^2), D3to4), [1 3 4 2]);
     % D3to4 is a channel from 3 to 4: Tr_{4}[D3to4] = I3
     PartialTrace(D3to4, [2], [d d]) == eye(d);

     % Tr_{46}[E] = I35 \otimes D1to2
     PartialTrace(E, [4 6], [d d d d d d]) == kron(eye(d^2), D1to2);
     % D1to2 is a channel from 1 to 2: Tr_{2}[D1to2] = I1
     PartialTrace(D1to2, [2], [d d]) == eye(d);
     
     % Tr_{2,4 6}[E] = I135
     PartialTrace(E, [2 4 6], [d d d d d d]) == eye(d^3);
     
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
if k==4
    'Waiting'
end %end if k==4
    cvx_end
end