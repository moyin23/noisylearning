function D_fea = learning_changetodualfeasible_parallel(D,d,k)
% Code that generate the dual operator 'D_fea' of a strictly feasible parallel
% learning network close to 'D'
% 'D' is the input dual operator
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)


% 1. Construct the non-floating-point matrix 'D_frac' by truncating
% the matrix 'D':
% keeping eight decimal digits, and then change to integer
    D_frac = learning_cut8(D);
% 2. Obtain a Hermition matrix
    D_Herm = (D_frac + D_frac')/2;
% 3. Project to the parallel learning network space:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
    if k == 2
    % D = D6
    % Corresponding projector: P(D) = D6
        D6 = kron(PartialTrace(D_Herm,6, [d d d d d d]), eye(d)/d);
        D_P = D6;
    % D2456 = D132456
    % Corresponding projector: P(D) = D - D2456 + D132456
    % Change order: 132456 -> 123456
        D2456 = PermuteSystems(kron(PartialTrace(D_P,[2 4 5 6], [d d d d d d]),eye(d^4)/(d^4)), [1 3 2 4 5 6]);
        D132456 = trace(D_P) * eye(d^6)/(d^6);
        D_P = D_P - D2456 + D132456;
    end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
    if k==3
    % D = D8
    % Corresponding projector: P(D) = D8
        D8 = kron(PartialTrace(D_Herm,8, [d d d d d d d d]), eye(d)/d);
        D_P = D8;
    % D24678 = D13524678
    % Corresponding projector: P(D) = D - D24678 + D13524678
    % Change order: 13524678 -> 12345678
        D24678 = PermuteSystems(kron(PartialTrace(D_P,[2 4 6 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [1 4 2 5 3 6 7 8]);
        D13524678 = trace(D_P) * eye(d^8)/(d^8);
        D_P = D_P - D24678 + D13524678;
    end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
    if k==4
    % D = D10
    % Corresponding projector: P(D) = D10
        D10 = kron(PartialTrace(D_Herm,10, [d d d d d d d d d d]), eye(d)/d);
        D_P = D10;
    % D2468910 = D13572468910
    % Corresponding projector: P(D) = D - D2468910 + D13572468910
    % Change order: 13572468910 -> 12345678910
        D2468910= PermuteSystems(kron(PartialTrace(D_P,[2 4 6 8 9 10], [d d d d d d d d d d]),eye(d^6)/(d^6)), [1 5 2 6 3 7 4 8 9 10]);
        D12345678910 = trace(D_P) * eye(d^10)/(d^10);
        D_P = D_P - D2468910 + D13572468910;
    end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%

% 4. Add 'I' to make sure positivity
    eigenvalue = eigs(D_P,(d^(2*k+2)));
    mineig = min(eigenvalue);
    D_P = D_P + ceil(abs(mineig)) * eye(d^(2*k+2));

% 5. Normalization
    tracenow = trace(D_P);
    D_fea = D_P * d^(k+1) / tracenow;  % Tr[D] = d^(k+1)



