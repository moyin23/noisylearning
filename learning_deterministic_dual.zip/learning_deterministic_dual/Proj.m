function state = Proj(n,j,a1,a2,d)
% Code that creates the projector state
% 'n' corresponds to the number of coulping spins
% 'j' corresponds to the number of totalspin
% 'a1' corresponds to the ordinal of the total spin for ket, 
% (how these qubits coulped)
% 'a2' corresponds to the ordinal of totalspin for bra
% 'd' corresponds to SU(d)

if d == 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
    if n == 2
        if j == 1
            ket1 = [1;0;0;0];  % |1,1> = |1/2,1/2>|1/2,1/2>
            ket2 = [0;sqrt(2)/2;sqrt(2)/2;0];  % |1,0> = |1/2,1/2>|1/2,-1/2>/sqrt(2) + |1/2,-1/2>|1/2,1/2>/sqrt(2) 
            ket3 = [0;0;0;1];  % |1,-1> = |1/2,-1/2>|1/2,-1/2>
            state = ket1*ket1' + ket2*ket2' + ket3*ket3';
        end
        if j == 0
            ket = [0;sqrt(2)/2;-sqrt(2)/2;0];% |0,0> = |1/2,1/2>|1/2,-1/2>/sqrt(2) - |1/2,-1/2>|1/2,1/2>/sqrt(2) 
            state = ket*ket';
        end
    end %end if n==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
    if n == 3
        if j == 1.5
            ket1 = [1;0;0;0;0;0;0;0];
            ket2 = [0;sqrt(3)/3;sqrt(3)/3;0;sqrt(3)/3;0;0;0];
            ket3 = [0;0;0;sqrt(3)/3;0;sqrt(3)/3;sqrt(3)/3;0];
            ket4 = [0;0;0;0;0;0;0;1];
            state = ket1*ket1' + ket2*ket2' + ket3*ket3' + ket4*ket4';
        end
        if j == 0.5
            ket11 = [0;sqrt(6)/3;-sqrt(6)/6;0;-sqrt(6)/6;0;0;0];
            ket12 = [0;0;0;sqrt(6)/6;0;sqrt(6)/6;-sqrt(6)/3;0];
            ket21 = [0;0;sqrt(2)/2;0;-sqrt(2)/2;0;0;0];
            ket22 = [0;0;0;sqrt(2)/2;0;-sqrt(2)/2;0;0];
            if a1 == 1
                if a2 == 1
                    state = ket11*ket11' + ket12*ket12';
                end
                if a2 == 2
                    state = ket11*ket21' + ket12*ket22';
                end
            end
            if a1 == 2
                if a2 == 1
                    state = ket21*ket11' + ket22*ket12';
                end
                if a2 == 2
                    state = ket21*ket21' + ket22*ket22';
                end
            end
        end
    end %end if n==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
    if n == 4
        if j == 2
            ket1 = [1;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0];
            ket2 = [0;1/2;1/2;0;  1/2;0;0;0;  1/2;0;0;0;  0;0;0;0];
            ket3 = [0;0;0;sqrt(6)/6;  0;sqrt(6)/6;sqrt(6)/6;0;  0;sqrt(6)/6;sqrt(6)/6;0;  sqrt(6)/6;0;0;0];
            ket4 = [0;0;0;0;  0;0;0;1/2;  0;0;0;1/2;  0;1/2;1/2;0];
            ket5 = [0;0;0;0;  0;0;0;0;  0;0;0;0;  0;0;0;1];
            state = ket1*ket1' + ket2*ket2' + ket3*ket3' + ket4*ket4' + ket5*ket5';
        end
        if j == 1
            ket11 = [0;sqrt(3)/2;-sqrt(3)/6;0;  -sqrt(3)/6;0;0;0;  -sqrt(3)/6;0;0;0;  0;0;0;0];
            ket12 = [0;0;0;sqrt(6)/6;  0;sqrt(6)/6;-sqrt(6)/6;0;  0;sqrt(6)/6;-sqrt(6)/6;0;  -sqrt(6)/6;0;0;0];
            ket13 = [0;0;0;0;  0;0;0;sqrt(3)/6;  0;0;0;sqrt(3)/6;  0;sqrt(3)/6;-sqrt(3)/2;0];
            ket21 = [0;0;sqrt(6)/3;0;  -sqrt(6)/6;0;0;0;  -sqrt(6)/6;0;0;0;  0;0;0;0];
            ket22 = [0;0;0;sqrt(3)/3;  0;-sqrt(3)/6;sqrt(3)/6;0;  0;-sqrt(3)/6;sqrt(3)/6;0;  -sqrt(3)/3;0;0;0];
            ket23 = [0;0;0;0;  0;0;0;sqrt(6)/6;  0;0;0;sqrt(6)/6;  0;-sqrt(6)/3;0;0];
            ket31 = [0;0;0;0;  sqrt(2)/2;0;0;0;  -sqrt(2)/2;0;0;0;  0;0;0;0];
            ket32 = [0;0;0;0;  0;1/2;1/2;0;  0;-1/2;-1/2;0;  0;0;0;0];
            ket33 = [0;0;0;0;  0;0;0;sqrt(2)/2;  0;0;0;-sqrt(2)/2;  0;0;0;0];
            if a1 == 1
                if a2 == 1
                    state = ket11*ket11' + ket12*ket12' + ket13*ket13';
                end
                if a2 == 2
                    state = ket11*ket21' + ket12*ket22' + ket13*ket23';
                end
                if a2 == 3
                    state = ket11*ket31' + ket12*ket32' + ket13*ket33';
                end
            end
            if a1 == 2
                if a2 == 1
                    state = ket21*ket11' + ket22*ket12' + ket23*ket13';
                end
                if a2 == 2
                    state = ket21*ket21' + ket22*ket22' + ket23*ket23';
                end
                if a2 == 3
                    state = ket21*ket31' + ket22*ket32' + ket23*ket33';
                end
            end
            if a1 == 3
                if a2 == 1
                    state = ket31*ket11' + ket32*ket12' + ket33*ket13';
                end
                if a2 == 2
                    state = ket31*ket21' + ket32*ket22' + ket33*ket23';
                end
                if a2 == 3
                    state = ket31*ket31' + ket32*ket32' + ket33*ket33';
                end
            end
        end % end j=1
        if j == 0
            ket11 = [0;0;0;sqrt(3)/3;  0;-sqrt(3)/6;-sqrt(3)/6;0;  0;-sqrt(3)/6;-sqrt(3)/6;0;  sqrt(3)/3;0;0;0];
            ket21 = [0;0;0;0;  0;1/2;-1/2;0;  0;-1/2;1/2;0;  0;0;0;0];
            if a1 == 1
                if a2 == 1
                    state = ket11*ket11';
                end
                if a2 == 2
                    state = ket11*ket21';
                end
            end
            if a1 == 2
                if a2 == 1
                    state = ket21*ket11';
                end
                if a2 == 2
                    state = ket21*ket21';
                end
            end
        end % end j=0
    end %end if n==4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 5 copies
%    if n == 5
%        state = zeros(32,32);
%        for m = 2.5:-1:-2.5
%            state = state + spin_ket(n,j,m,a1,d)*spin_ket(n,j,m,a2,d)';
%        end
%    end %end if n==5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 6 copies
%    if n == 6
%        state = zeros(64,64);
%        for m = 3:-1:-3
%            state = state + spin_ket(n,j,m,a1,d)*spin_ket(n,j,m,a2,d)';
%        end
%    end %end if n==6
end
end