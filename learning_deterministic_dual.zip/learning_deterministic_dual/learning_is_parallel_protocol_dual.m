function learning_is_parallel_protocol_dual(D,d,k)
% Code that imposes SPD constrains on a variable D to enforce that D is a
% valid dual operator of a parallel learning network
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)

%  Important: To write the equality constraints of the Choi operator of the
%  quantum network, we need to make sure the systems for the left hand side
%  and the right hand side coulping in the same order.

    cvx_begin SDP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
     % Declare the SDP variables corresponding to the encoders with memory
     % D = D6
     D == kron(PartialTrace(D,6,[d d d d d d]), eye(d)/d);
     % D2456 = D132456
     PartialTrace(D,[2 4 5 6],[d d d d d d]) == eye(d^k)/(d^k) * trace(D);
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3
     % Declare the SDP variables corresponding to the encoders with memory
     % D = D8
     D == kron(PartialTrace(D,8,[d d d d d d d d]), eye(d)/d);
     % D24678 = D13524678
     PartialTrace(D,[2 4 6 7 8],[d d d d d d d d]) == eye(d^k)/(d^k) * trace(D);
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
if k==4  
     % Declare the SDP variables corresponding to the encoders with memory
     % D = D10
     D == kron(PartialTrace(D,10,[d d d d d d d d d d]), eye(d)/d);
     % D2468910 = D13572468910
     PartialTrace(D,[2 4 6 8 9 10],[d d d d d d d d d d]) == eye(d^k)/(d^k) * trace(D);
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);
end %end if k==4
    cvx_end
end
