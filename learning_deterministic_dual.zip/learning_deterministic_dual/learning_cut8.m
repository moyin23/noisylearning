function outC = learning_cut8(C)
% Code to truncate the matrix
% Truncating the matrix is done by keeping eight decimal digits.
% Note: in this problem, the integer part is not large, so keep eight
% decimal digits cause no problems.
% To deal with floating-point rounding errors, we times 10^8 and output a
% matrix with all integer numbers.

    d = length(C);
    outC = zeros(d);
    
    for i = 1:d
        for j = 1:d
            outC(i,j) = floor( C(i,j)*10^8 );  
            % Truncating by keeping eight decimal digits, and then change to integer.
            if abs(outC(i,j)) < 5
                outC(i,j) = 0;
        end
    end
    
end