function D_fea = learning_changetodualfeasible_general(D,d,k)
% Code that generate the dual operator 'D_fea' of a strictly feasible
% general learning network close to 'D'
% 'D' is the input dual operator
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)

% Note: for k = 4, hasn't been finished.


% 1. Construct the non-floating-point matrix 'D_frac' by truncating
% the matrix 'D':
% keeping eight decimal digits, and then change to integer
    D_frac = learning_cut8(D);
% 2. Obtain a Hermition matrix
    D_Herm = (D_frac + D_frac')/2;
% 3. Project to the parallel learning network space:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
    if k == 2
    % D = D6
    % Corresponding projector: P(D) = D6
        D6 = kron(PartialTrace(D_Herm,6, [d d d d d d]), eye(d)/d);
        D_P = D6;
        
     % Denote: E = Tr_{56}[D] / d
     % Denote: D3to4 = Tr_{12}[E] / d
     % Denote: D1to2 = Tr_{34}[E] / d
     
     % Tr_{2}[E] = I1 \otimes D3to4
     % D3to4 is a channel from 3 to 4: Tr_{4}[D3to4] = I3
     % Corresponding projector: P(D) = D - D256 + D1256
     % Corresponding projector: P(D) = D - D12456 + D123456
     % Change order: 134256, 341256 -> 123456
     % Change order: 312456 -> 123456
        D256 = PermuteSystems(kron(PartialTrace(D_P,[2 5 6], [d d d d d d]),eye(d^3)/(d^3)), [1 4 2 3 5 6]);
        D1256 = PermuteSystems(kron(PartialTrace(D_P,[1 2 5 6], [d d d d d d]),eye(d^4)/(d^4)), [3 4 1 2 5 6]);
        D12456 = PermuteSystems(kron(PartialTrace(D_P,[1 2 4 5 6], [d d d d d d]),eye(d^5)/(d^5)), [2 3 1 4 5 6]);
        D123456 = trace(D_P) * eye(d^6)/(d^6);
        D_P = D_P - D256 + D1256;
        D_P = D_P - D12456 + D123456;
        
     % Tr_{4}[E] = I3 \otimes D1to2
     % D1to2 is a channel from 1 to 2: Tr_{2}[D1to2] = I1
     % Corresponding projector: P(D) = D - D456 + D3456
     % Corresponding projector: P(D) = D - D23456 + D123456
        D456 = kron(PartialTrace(D_P,[4 5 6], [d d d d d d]),eye(d^3)/(d^3));
        D3456 = kron(PartialTrace(D_P,[3 4 5 6], [d d d d d d]),eye(d^4)/(d^4));
        D23456 = kron(PartialTrace(D_P,[2 3 4 5 6], [d d d d d d]),eye(d^5)/(d^5));
        D_P = D_P - D456 + D3456;
        D_P = D_P - D23456 + D123456;
     
     
     % Tr_{2,4}[E] = I13
     % Corresponding projector: P(D) = D - D2456 + D123456
     % Change order: 132456 -> 123456
        D2456 = PermuteSystems(kron(PartialTrace(D_P,[2 4 5 6], [d d d d d d]),eye(d^4)/(d^4)), [1 3 2 4 5 6]);
        D_P = D_P - D2456 + D132456;
    end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
    if k==3
    % D = D8
    % Corresponding projector: P(D) = D8
        D8 = kron(PartialTrace(D_Herm,8, [d d d d d d d d]), eye(d)/d);
        D_P = D8;

     % Denote: E = Tr_{78}[D] / d
     % Denote: D35to46 = Tr_{12}[E] / d
     % Denote: D15to26 = Tr_{34}[E] / d
     % Denote: D13to24 = Tr_{56}[E] / d
     % Denote: D5to6 = Tr_{1234}[E] / d^2
     % Denote: D3to4 = Tr_{1256}[E] / d^2
     % Denote: D1to2 = Tr_{3456}[E] / d^2

     % Tr_{2}[E] = I1 \otimes D35to46
     % D35to46 is a channel from 35 to 46: Tr_{46}[D35to46] = I35
     % Corresponding projector: P(D) = D - D278 + D1278
     % Corresponding projector: P(D) = D - D124678 + D12345678
     % Change order: 13456278, 34561278 -> 12345678
     % Change order: 35124678 -> 12345678
        D278 = PermuteSystems(kron(PartialTrace(D_P,[2 7 8], [d d d d d d d d]),eye(d^3)/(d^3)), [1 6 2 3 4 5 7 8]);
        D1278 = PermuteSystems(kron(PartialTrace(D_P,[1 2 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [5 6 1 2 3 4 7 8]);
        D124678 = PermuteSystems(kron(PartialTrace(D_P,[1 2 4 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [3 4 1 5 2 6 7 8]);
        D12345678 = trace(D_P) * eye(d^8)/(d^8);
        D_P = D_P - D278 + D1278;
        D_P = D_P - D124678 + D12345678;
     
     % Tr_{4}[E] = I3 \otimes D15to26
     % D15to26 is a channel from 15 to 26: Tr_{26}[D15to26] = I15
     % Corresponding projector: P(D) = D - D478 + D3478
     % Corresponding projector: P(D) = D - D234678 + D12345678
     % Change order: 12356478, 12563478 -> 12345678
     % Change order: 15234678 -> 12345678
        D478 = PermuteSystems(kron(PartialTrace(D_P,[4 7 8], [d d d d d d d d]),eye(d^3)/(d^3)), [1 2 3 6 4 5 7 8]);
        D3478 = PermuteSystems(kron(PartialTrace(D_P,[3 4 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 2 5 6 3 4 7 8]);
        D234678 = PermuteSystems(kron(PartialTrace(D_P,[1 2 4 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [1 3 4 5 2 6 7 8]);
        D_P = D_P - D478 + D3478;
        D_P = D_P - D234678 + D12345678;
     
     % Tr_{6}[E] = I5 \otimes D13to24
     % D13to24 is a channel from 13 to 24: Tr_{24}[D13to24] = I13
     % Corresponding projector: P(D) = D - D678 + D5678
     % Corresponding projector: P(D) = D - D245678 + D12345678
     % Change order: 13245678-> 12345678
        D678 = kron(PartialTrace(D_P,[6 7 8], [d d d d d d d d]),eye(d^3)/(d^3));
        D5678 = kron(PartialTrace(D_P,[5 6 7 8], [d d d d d d d d]),eye(d^4)/(d^4));
        D245678 = PermuteSystems(kron(PartialTrace(D_P,[2 4 5 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [1 3 2 4 5 6 7 8]);
        D_P = D_P - D678 + D5678;
        D_P = D_P - D245678 + D12345678;
     
     % Tr_{24}[E] = I13 \otimes D5to6
     % D5to6 is a channel from 5 to 6: Tr_{6}[D5to6] = I5
     % Corresponding projector: P(D) = D - D2478 + D123478
     % Corresponding projector: P(D) = D - D1234678 + D12345678
     % Change order: 13562478, 56123478 -> 12345678
     % Change order: 51234678 -> 12345678
        D2478 = PermuteSystems(kron(PartialTrace(D_P,[2 4 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 5 2 6 3 4 7 8]);
        D123478 = PermuteSystems(kron(PartialTrace(D_P,[1 2 3 4 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [3 4 5 6 1 2 7 8]);
        D1234678 = PermuteSystems(kron(PartialTrace(D_P,[1 2 3 4 6 7 8], [d d d d d d d d]),eye(d^7)/(d^7)), [2 3 4 5 1 6 7 8]);
        D_P = D_P - D2478 + D123478;
        D_P = D_P - D1234678 + D12345678;
     
     % Tr_{26}[E] = I15 \otimes D3to4
     % D3to4 is a channel from 3 to 4: Tr_{4}[D3to4] = I3
     % Corresponding projector: P(D) = D - D2678 + D125678
     % Corresponding projector: P(D) = D - D1245678 + D12345678
     % Change order: 13452678, 34125678 -> 12345678
     % Change order: 31245678 -> 12345678
        D2678 = PermuteSystems(kron(PartialTrace(D_P,[2 6 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 5 2 3 4 6 7 8]);
        D125678 = PermuteSystems(kron(PartialTrace(D_P,[1 2 5 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [3 4 1 2 5 6 7 8]);
        D1245678 = PermuteSystems(kron(PartialTrace(D_P,[1 2 4 5 6 7 8], [d d d d d d d d]),eye(d^7)/(d^7)), [2 3 1 4 5 6 7 8]);
        D_P = D_P - D2678 + D125678;
        D_P = D_P - D1245678 + D12345678;
        
     % Tr_{46}[E] = I35 \otimes D1to2
     % D1to2 is a channel from 1 to 2: Tr_{2}[D1to2] = I1
     % Corresponding projector: P(D) = D - D4678 + D345678
     % Corresponding projector: P(D) = D - D2345678 + D12345678
     % Change order: 12354678 -> 12345678
        D4678 = PermuteSystems(kron(PartialTrace(D_P,[4 6 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 2 3 5 4 6 7 8]);
        D345678 = kron(PartialTrace(D_P,[3 4 5 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6));
        D2345678 = kron(PartialTrace(D_P,[2 3 4 5 6 7 8], [d d d d d d d d]),eye(d^7)/(d^7));
        D_P = D_P - D4678 + D345678;
        D_P = D_P - D2345678 + D12345678;
     
     % Tr_{2,4 6}[E] = I135
     % Corresponding projector: P(D) = D - D24678 + D12345678
     % Change order: 13524678 -> 12345678
     D24678 = PermuteSystems(kron(PartialTrace(D_P,[2 4 6 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [1 4 2 5 3 6 7 8]);
     D_P = D_P - D24678 + D12345678;
     
    end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
    if k==4
        'Missing'
    end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%

% 4. Add 'I' to make sure positivity
    eigenvalue = eigs(D_P,(d^(2*k+2)));
    mineig = min(eigenvalue);
    D_P = D_P + ceil(abs(mineig)) * eye(d^(2*k+2));

% 5. Normalization
    tracenow = trace(D_P);
    D_fea = D_P * d^(k+1) / tracenow;  % Tr[D] = d^(k+1)



