function learning_is_sequential_protocol_dual(D,d,k)
% Code that imposes SPD constrains on a variable D to enforce that D is a
% valid dual operator of a sequential learning network
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)

%  Important: To write the equality constraints of the Choi operator of the
%  quantum network, we need to make sure the systems for the left hand side
%  and the right hand side coulping in the same order.

    cvx_begin SDP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
     % Declare the SDP variables corresponding to the encoders with memory
     % D = D6
     D == kron(PartialTrace(D,6,[d d d d d d]), eye(d)/d);
     % D456 = D3456
     PartialTrace(D,[4 5 6],[d d d d d d]) == kron(PartialTrace(D,[3 4 5 6],[d d d d d d]), eye(d)/d);
     % D23456 = D123456
     PartialTrace(D,[2 3 4 5 6],[d d d d d d]) == eye(d)/(d) * trace(D);
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3  
     % D = D8
     D == kron(PartialTrace(D,8,[d d d d d d d d]), eye(d)/d);
     % D678 = D5678
     PartialTrace(D,[6 7 8],[d d d d d d d d]) == kron(PartialTrace(D,[5 6 7 8],[d d d d d d d d]), eye(d)/d);
     % D45678 = D345678
     PartialTrace(D,[4 5 6 7 8],[d d d d d d d d]) == kron(PartialTrace(D,[3 4 5 6 7 8],[d d d d d d d d]), eye(d)/d);
     % D2345678 = D12345678
     PartialTrace(D,[2 3 4 5 6 7 8],[d d d d d d d d]) == eye(d)/(d) * trace(D);
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);   
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
if k==4  
     % D = D10
     D == kron(PartialTrace(D,10,[d d d d d d d d d d]), eye(d)/d);
     % D8910 = D78910
     PartialTrace(D,[8 9 10],[d d d d d d d d d d]) == kron(PartialTrace(D,[7 8 9 10],[d d d d d d d d d d]), eye(d)/d);
     % D678910 = D5678910
     PartialTrace(D,[6 7 8 9 10],[d d d d d d d d d d]) == kron(PartialTrace(D,[5 6 7 8 9 10],[d d d d d d d d d d]), eye(d)/d);
     % D45678910 = D345678910
     PartialTrace(D,[4 5 6 7 8 9 10],[d d d d d d d d d d]) == kron(PartialTrace(D,[3 4 5 6 7 8 9 10],[d d d d d d d d d d]), eye(d)/d);
     % D2345678910 = D12345678910
     PartialTrace(D,[2 3 4 5 6 7 8 9 10],[d d d d d d d d d d]) == eye(d)/(d) * trace(D);
     % Trace(D) = d^(k+1)
     trace(D) == d^(k+1);     
end %end if k==4
    cvx_end
end
