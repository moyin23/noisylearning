function upperbound = learning_maxf_dual_feasible(Omega, D_fea)
% Code to get an upper bound from a feasible dual solution
% Note: In dual problem, we minimise '\lambda'
% such that: \lambda * D >= Omega
    cvx_begin SDP
    %cvx_solver mosek
    
    variable lambda
    minimise lambda  % get the optimal performance
    lambda * D_fea >= Omega;
    
    cvx_end
    
    upperbound = lambda;
    
end