function [maxf C]=learning_maxf_sequential(k,g,d,isComplex)
% Code that find the maximal fidelity of learning unitary U from
% noisy learning samples with a 'sequantial' storing
% 'k' corresponds to the total number of the learning gates
% 'g' corresponds to how many good gates are used
% 'd' corresponds to SU(d)
% if isComplex is '0', the code only consider supermaps with real numbers
% is isComples is '1', the code considers general supermaps with complex
% numbers

Omega = learning_omega(k,g,d);  %  Get the performance operator

'SEQUENTIAL PROTOCOL'
    cvx_begin SDP
    %cvx_solver mosek
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
    variable f
   % Declare the SDP variables related to C
    if isComplex==1
        variable C(d^6,d^6) complex semidefinite
    else
        variable C(d^6,d^6) semidefinite
    end
    maximise f  % get the optimal performance
    f == trace(C * Omega);
    learning_is_sequential_protocol(C,d,k);  % make sure C is a sequential learning network
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3
    variable f
    % Declare the SDP variables related to C
    if isComplex==1
        variable C(d^8,d^8) complex semidefinite
    else
        variable C(d^8,d^8) semidefinite
    end
    maximise f  % get the optimal performance
    f == trace(C * Omega);
    %maximise trace(C * Omega)
    learning_is_sequential_protocol(C,d,k);  % make sure C is a sequential learning network
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
if k==4
    variable f
   % Declare the SDP variables related to C
    if isComplex==1
        variable C(d^10,d^10) complex semidefinite
    else
        variable C(d^10,d^10) semidefinite
    end
    maximise f  % get the optimal performance
    f == trace(C * Omega);
    learning_is_sequential_protocol(C,d,k);  % make sure C is a sequential learning network
end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%
%finish SDP
    cvx_end
    maxf=f;
    C=C;
end