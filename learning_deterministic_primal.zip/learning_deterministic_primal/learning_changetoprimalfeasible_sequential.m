function C_fea = learning_changetoprimalfeasible_sequential(C,d,k)
% Code that generate the Choi operator 'C_fea' of a strictly feasible sequential learning network
% close to 'C'
% 'C' is the input Choi operator
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)


% 1. Construct the non-floating-point matrix 'C_frac' by truncating
% the matrix 'C:
% keeping eight decimal digits, and then change to integer
    C_frac = learning_cut8(C);
% 2. Obtain a Hermition matrix
    C_Herm = (C_frac + C_frac')/2;
% 3. Project to the sequential learning network space:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
    if k == 2
    % Tr_6[C] = Tr_{456}[C] \otimes I_45
    % Corresponding projector: P(C) = C - C6 + C456
        C6 = kron(PartialTrace(C_Herm,6, [d d d d d d]), eye(d)/d);
        C456 = kron(PartialTrace(C_Herm,[4 5 6], [d d d d d d]), eye(d^3)/(d^3));
        C_P = C_Herm - C6 + C456;
    % Tr_{3456}[C] = Tr_{23456}[C] \otimes I_3
    % Corresponding projector: P(C) = C - C3456 + C23456
        C3456 = kron(PartialTrace(C_P,[3 4 5 6], [d d d d d d]), eye(d^4)/(d^4));
        C23456 = kron(PartialTrace(C_P,[2 3 4 5 6], [d d d d d d]), eye(d^5)/(d^5));
        C_P = C_P - C3456 + C23456;
    end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
    if k==3
    % Tr_8[C] = Tr_{678}[C] \otimes I_67
    % Corresponding projector: P(C) = C - C8 + C678
        C8 = kron(PartialTrace(C_Herm,8, [d d d d d d d d]), eye(d)/d);
        C678 = kron(PartialTrace(C_Herm,[6 7 8], [d d d d d d d d]), eye(d^3)/(d^3));
        C_P = C_Herm - C8 + C678;
    % Tr_{5678}[C] = Tr_{45678}[C] \otimes I_4
    % Corresponding projector: P(C) = C - C5678 + C45678
        C5678 = kron(PartialTrace(C_P,[5 6 7 8], [d d d d d d d d]), eye(d^4)/(d^4));
        C45678 = kron(PartialTrace(C_P,[4 5 6 7 8], [d d d d d d d d]), eye(d^5)/(d^5));
        C_P = C_P - C5678 + C45678;
    % Tr_{345678}[C] = Tr_{2345678}[C] \otimes I_2
    % Corresponding projector: P(C) = C - C345678 + C2345678
        C345678 = kron(PartialTrace(C_P,[3 4 5 6 7 8], [d d d d d d d d]), eye(d^6)/(d^6));
        C2345678 = kron(PartialTrace(C_P,[2 3 4 5 6 7 8], [d d d d d d d d]), eye(d^7)/(d^7));
        C_P = C_P - C345678 + C2345678;
    end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
    if k==4
    % Tr_10[C] = Tr_{8910}[C] \otimes I_89
    % Corresponding projector: P(C) = C - C10 + C8910
        C10 = kron(PartialTrace(C_Herm,10, [d d d d d d d d d d]), eye(d)/d);
        C8910 = kron(PartialTrace(C_Herm,[8 9 10], [d d d d d d d d d d]), eye(d^3)/(d^3));
        C_P = C_Herm - C10 + C8910;
    % Tr_{78910}[C] = Tr_{678910}[C] \otimes I_6
    % Corresponding projector: P(C) = C - C78910 + C678910
        C78910 = kron(PartialTrace(C_P,[7 8 9 10], [d d d d d d d d d d]), eye(d^4)/(d^4));
        C678910 = kron(PartialTrace(C_P,[6 7 8 9 10], [d d d d d d d d d d]), eye(d^5)/(d^5));
        C_P = C_P - C78910 + C678910;
    % Tr_{5678910}[C] = Tr_{45678910}[C] \otimes I_4
    % Corresponding projector: P(C) = C - C5678910 + C45678910
        C5678910 = kron(PartialTrace(C_P,[5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^6)/(d^6));
        C45678910 = kron(PartialTrace(C_P,[4 5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^7)/(d^7));
        C_P = C_P - C5678910 + C45678910;
    % Tr_{345678910}[C] = Tr_{2345678910}[C] \otimes I_2
    % Corresponding projector: P(C) = C - C5678910 + C45678910
        C345678910 = kron(PartialTrace(C_P,[3 4 5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^8)/(d^8));
        C2345678910 = kron(PartialTrace(C_P,[2 3 4 5 6 7 8 9 10], [d d d d d d d d d d]), eye(d^9)/(d^9));
        C_P = C_P - C345678910 + C2345678910;
    end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%

% 4. Add 'I' to make sure positivity
    eigenvalue = eigs(C_P,(d^(2*k+2)));
    mineig = min(eigenvalue);
    C_P = C_P + ceil(abs(mineig)) * eye(d^(2*k+2));

% 5. Normalization
    tracenow = trace(C_P);
    C_fea = C_P * d^(k+1) / tracenow;  % Tr[C] = d^(k+1)

