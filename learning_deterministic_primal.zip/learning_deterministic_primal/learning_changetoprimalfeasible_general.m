function C_fea = learning_changetoprimalfeasible_general(C,d,k)
% Code that generate the Choi operator 'C_fea' of a strictly feasible general learning network
% close to 'C'
% 'C' is the input Choi operator
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)

% Note: for k = 4, hasn't been finished.


% 1. Construct the non-floating-point matrix 'C_frac' by truncating
% the matrix 'C:
% keeping eight decimal digits, and then change to integer
    C_frac = learning_cut8(C);
% 2. Obtain a Hermition matrix
    C_Herm = (C_frac + C_frac')/2;
% 3. Project to the general learning network space:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
    if k == 2
    % Tr_6[C] = Tr_{56}[C] \otimes I_5
    % Corresponding projector: P(C) = C - C6 + C56
        C6 = kron(PartialTrace(C_Herm,6, [d d d d d d]), eye(d)/d);
        C56 = kron(PartialTrace(C_Herm,[5 6], [d d d d d d]), eye(d^2)/(d^2));
        C_P = C_Herm - C6 + C56;
    % D12 = D1
    % Corresponding projector: P(C) = C - D12 + D1
        D12 = kron(PartialTrace(C_P,[3 4 5 6], [d d d d d d]), eye(d^4)/(d^4));
        D1 = kron(PartialTrace(C_P,[2 3 4 5 6], [d d d d d d]), eye(d^5)/(d^5));
        C_P = C_P - D12 + D1;
    % D34 = D3
    % Corresponding projector: P(C) = C - D34 + D3
    % Change order: 341256, 312456 -> 123456
        D34 = PermuteSystems(kron(PartialTrace(C_P,[1 2 5 6], [d d d d d d]),eye(d^4)/(d^4)), [3 4 1 2 5 6]);
        D3 = PermuteSystems(kron(PartialTrace(C_P,[1 2 4 5 6], [d d d d d d]),eye(d^5)/(d^5)), [2 3 1 4 5 6]);
        C_P = C_P - D34 + D3;
    % D1234 + D13 = D123 + D134       
    % Corresponding projector: P(C) = C - D1234 - D13 + D123 + D134 
    % Change order: 132456, 134256 -> 123456
        D1234 = kron(PartialTrace(C_P,[5 6], [d d d d d d]), eye(d^2)/(d^2));
        D13 = PermuteSystems(kron(PartialTrace(C_P,[2 4 5 6], [d d d d d d]),eye(d^4)/(d^4)), [1 3 2 4 5 6]);
        D123 = kron(PartialTrace(C_P,[4 5 6], [d d d d d d]), eye(d^3)/(d^3));
        D134 = PermuteSystems(kron(PartialTrace(C_P,[2 5 6], [d d d d d d]),eye(d^3)/(d^3)), [1 4 2 3 5 6]);
        C_P = C_P - D1234 - D13 + D123 + D134;
    end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
    if k==3
    % Tr_8[C] = Tr_{78}[C] \otimes I_7
    % Corresponding projector: P(C) = C - C8 + C78
        C8 = kron(PartialTrace(C_Herm,8, [d d d d d d d d]), eye(d)/d);
        C78 = kron(PartialTrace(C_Herm,[7 8], [d d d d d d d d]), eye(d^2)/(d^2));
        C_P = C_Herm - C8 + C78;
    % D56 = D5
    % Corresponding projector: P(C) = C - D56 + D5
    % Change order: 56123478, 51234678 -> 12345678
        D56 = PermuteSystems(kron(PartialTrace(C_P,[1 2 3 4 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [3 4 5 6 1 2 7 8]);
        D5 = PermuteSystems(kron(PartialTrace(C_P,[1 2 3 4 6 7 8], [d d d d d d d d]),eye(d^7)/(d^7)), [2 3 4 5 1 6 7 8]);
        C_P = C_P - D56 + D5;
    % D34 = D3
    % Corresponding projector: P(C) = C - D34 + D3
    % Change order: 34125678, 31245678 -> 12345678
        D34 = PermuteSystems(kron(PartialTrace(C_P,[1 2 5 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [3 4 1 2 5 6 7 8]);
        D3 = PermuteSystems(kron(PartialTrace(C_P,[1 2 4 5 6 7 8], [d d d d d d d d]),eye(d^7)/(d^7)), [2 3 1 4 5 6 7 8]);
        C_P = C_P - D34 + D3;
    % D12 = D1
    % Corresponding projector: P(C) = C - D12 + D1
        D12 = kron(PartialTrace(C_P,[3 4 5 6 7 8], [d d d d d d d d]), eye(d^6)/(d^6));
        D1 = kron(PartialTrace(C_P,[2 3 4 5 6 7 8], [d d d d d d d d]), eye(d^7)/(d^7));
        C_P = C_P - D12 + D1;

    % D3456 + D35 = D345 + D356
    % Corresponding projector: P(C) = C - D3456 - D35 + D345 + D356 
    % Change order: 34561278, 35124678, 34512678, 35612478 -> 12345678
        D3456 = PermuteSystems(kron(PartialTrace(C_P,[1 2 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [5 6 1 2 3 4 7 8]);
        D35 = PermuteSystems(kron(PartialTrace(C_P,[1 2 4 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [3 4 1 5 2 6 7 8]);
        D345 = PermuteSystems(kron(PartialTrace(C_P,[1 2 6 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [4 5 1 2 3 6 7 8]);
        D356 = PermuteSystems(kron(PartialTrace(C_P,[1 2 4 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [4 5 1 6 2 3 7 8]);
        C_P = C_P - D3456 - D35 + D345 + D356;
        
    % D1256 + D15 = D125 + D156
    % Corresponding projector: P(C) = C - D1256 - D15 + D125 + D156
    % Change order: 12563478, 15234678, 12534678, 15623478 -> 12345678
        D1256 = PermuteSystems(kron(PartialTrace(C_P,[3 4 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 2 5 6 3 4 7 8]);
        D15 = PermuteSystems(kron(PartialTrace(C_P,[2 3 4 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [1 3 4 5 2 6 7 8]);
        D125 = PermuteSystems(kron(PartialTrace(C_P,[3 4 6 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [1 2 4 5 3 6 7 8]);
        D156 = PermuteSystems(kron(PartialTrace(C_P,[2 3 4 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [1 4 5 6 2 3 7 8]);
        C_P = C_P - D1256 - D15 + D125 + D156;
        
    % D1234 + D13 = D123 + D134
    % Corresponding projector: P(C) = C - D1234 - D13 + D123 + D134 
    % Change order: 13245678, 13425678 -> 12345678
        D1234 = kron(PartialTrace(C_P,[5 6 7 8], [d d d d d d d d]), eye(d^4)/(d^4));
        D13 = PermuteSystems(kron(PartialTrace(C_P,[2 4 5 6 7 8], [d d d d d d d d]),eye(d^6)/(d^6)), [1 3 2 4 5 6 7 8]);
        D123 = kron(PartialTrace(C_P,[4 5 6 7 8], [d d d d d d d d]), eye(d^5)/(d^5));
        D134 = PermuteSystems(kron(PartialTrace(C_P,[2 5 6 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [1 4 2 3 5 6 7 8]);
        C_P = C_P - D1234 - D13 + D123 + D134;
    
    % D123456 - D135 = D13524 + D13526 + D13546 - D1352 - D1354 - D1356
    % Corresponding projector: P(C) = C - D123456 - D1352 - D1354 - D1356 +
    % D13524 + D13526 + D13546 + D135
    % Change order: 12354678, 13452678, 13562478, 12356478, 13456278, 13524678 -> 12345678
        D123456 = kron(PartialTrace(C_P,[7 8], [d d d d d d d d]), eye(d^2)/(d^2));
        D135 = PermuteSystems(kron(PartialTrace(C_P,[2 4 6 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [1 4 2 5 3 6 7 8]);
        D13524 = kron(PartialTrace(C_P,[6 7 8], [d d d d d d d d]), eye(d^3)/(d^3));
        D13526 = PermuteSystems(kron(PartialTrace(C_P,[4 7 8], [d d d d d d d d]),eye(d^3)/(d^3)), [1 2 3 6 4 5 7 8]);
        D13546 = PermuteSystems(kron(PartialTrace(C_P,[2 7 8], [d d d d d d d d]),eye(d^3)/(d^3)), [1 6 2 3 4 5 7 8]);
        D1352 = PermuteSystems(kron(PartialTrace(C_P,[4 6 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 2 3 5 4 6 7 8]);
        D1354 = PermuteSystems(kron(PartialTrace(C_P,[2 6 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 5 2 3 4 6 7 8]);
        D1356 = PermuteSystems(kron(PartialTrace(C_P,[2 4 7 8], [d d d d d d d d]),eye(d^4)/(d^4)), [1 5 2 6 3 4 7 8]);
        C_P = C_P - D123456 - D1352 - D1354 - D1356 + D13524 + D13526 + D13546 + D135;
    end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
    if k==4
        'missing'
    end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%

% 4. Add 'I' to make sure positivity
    eigenvalue = eigs(C_P,(d^(2*k+2)));
    mineig = min(eigenvalue);
    C_P = C_P + ceil(abs(mineig)) * eye(d^(2*k+2));

% 5. Normalization
    tracenow = trace(C_P);
    C_fea = C_P * d^(k+1) / tracenow;  % Tr[C] = d^(k+1)

