% This gives the optimal fidelity to learn gate 'U' using 'k' learning gates and only 'g' of them are good
% The noisy gates are completely depolarizing channnels.
% An lower bound if provided by primal feasible solution.


        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%  Start of Adjustable Parameters  %%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                d=2               %Dimension 'd' % This program only works for d=2 now.
                k=3               %Number of uses 'k'
                g=2               %Number of good unitaries
                chose_protocol=3; %1 for parallel, 2 for sequential, 3 for general
                isComplex=0;      %Set isComples=0 to restric to supermaps with real coefficients
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%   End of Adjustable Parameters   %%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
% Generate the performance operator
Omega = learning_omega(k,g,d);
% Find the maximal fidelity of learning unitary U from 
% 'k' learning samples, with 'g' noisy gates
if chose_protocol==1
    [maxf C]=learning_maxf_parallel(k,g,d,isComplex);  %Assuming a parallel protocol
    C_fea = learning_changetoprimalfeasible_parallel(C,d,k);  % Make C primal feasible
    lowerbound_parallel = trace(Omega*C_fea)  % Get an lower bound from primal problem
end
if chose_protocol==2
    [maxf C]=learning_maxf_sequential(k,g,d,isComplex);  %Assuming a sequential protocol
    C_fea = learning_changetoprimalfeasible_sequential(C,d,k);  % Make C primal feasible
    lowerbound_sequential = trace(Omega*C_fea)  % Get an lower bound from primal problem
end
if chose_protocol==3
    [maxf C]=learning_maxf_general(k,g,d,isComplex);  %Assuming a general protocol
    C_fea = learning_changetoprimalfeasible_general(C,d,k);  % Make C primal feasible
    lowerbound_general = trace(Omega*C_fea)  % Get an lower bound from primal problem
end
    %maximal_fidelity=maxf;
    total_time_in_minutes=toc/60