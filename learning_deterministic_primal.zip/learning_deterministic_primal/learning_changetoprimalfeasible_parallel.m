function C_fea = learning_changetoprimalfeasible_parallel(C,d,k)
% Code that generate the Choi operator 'C_fea' of a strictly feasible parallel learning network
% close to 'C'
% 'C' is the input Choi operator
% 'k' corresponds to the total number of the learning gates
% 'd' corresponds to SU(d)


% 1. Construct the non-floating-point matrix 'C_frac' by truncating
% the matrix 'C:
% keeping eight decimal digits, and then change to integer
    C_frac = learning_cut8(C);
% 2. Obtain a Hermition matrix
    C_Herm = (C_frac + C_frac')/2;
% 3. Project to the parallel learning network space:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
    if k == 2
    % Tr_6[C] = Tr_{2456}[C] \otimes I_245
    % Corresponding projector: P(C) = C - C6 + C2456
    % Change order: 132456 -> 123456
        C6 = kron(PartialTrace(C_Herm,6, [d d d d d d]), eye(d)/d);
        C2456 = PermuteSystems(kron(PartialTrace(C_Herm,[2 4 5 6], [d d d d d d]),eye(d^4)/(d^4)), [1 3 2 4 5 6]);
        C_P = C_Herm - C6 + C2456;
    end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
    if k==3
    % Tr_8[C] = Tr_{24678}[C] \otimes I_2467
    % Corresponding projector: P(C) = C - C8 + C24678
    % Change order: 13524678 -> 12345678
        C8 = kron(PartialTrace(C_Herm,8, [d d d d d d d d]), eye(d)/d);
        C24678 = PermuteSystems(kron(PartialTrace(C_Herm,[2 4 6 7 8], [d d d d d d d d]),eye(d^5)/(d^5)), [1 4 2 5 3 6 7 8]);
        C_P = C_Herm - C8 + C24678;
    end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 4 copies
    if k==4
    % Tr_{10}[C] = Tr_{2468910}[C] \otimes I_24689
    % Corresponding projector: P(C) = C - C10 + C2468910
    % Change order: 13572468910 -> 12345678910
        C10 = kron(PartialTrace(C_Herm,10, [d d d d d d d d d d]), eye(d)/d);
        C2468910 = PermuteSystems(kron(PartialTrace(C_Herm,[2 4 6 8 9 10], [d d d d d d d d d d]),eye(d^6)/(d^6)), [1 5 2 6 3 7 4 8 9 10]);
        C_P = C_Herm - C10 + C2468910;
    end %end if k==4
%%%%%%%%%%%%%%%%%%%%%%%%

% 4. Add 'I' to make sure positivity
    eigenvalue = eigs(C_P,(d^(2*k+2)));
    mineig = min(eigenvalue);
    C_P = C_P + ceil(abs(mineig)) * eye(d^(2*k+2));

% 5. Normalization
    tracenow = trace(C_P);
    C_fea = C_P * d^(k+1) / tracenow;  % Tr[C] = d^(k+1)



