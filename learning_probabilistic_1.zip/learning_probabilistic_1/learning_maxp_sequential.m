function [maxp S F]=learning_maxp_sequential(Jin,Jout,k,g,d,isComplex)
% Code that find the maximal success probability of learning unitary U from
% noisy learning samples with a 'sequential' storing
% 'Jin(:,:,i)' corresponds to the Choi input of the i-th learning gates
% 'Jout(:,:,i)' corresponds to the Choi output operations of the i-th target gates
% 'k' corresponds to the total number of the learning gates
% 'g' corresponds to how many good gates are used
% 'd' corresponds to SU(d)
% isComples=0 for supermaps with real coefficients

n_in=size(Jin,3);  %Count the number of choi operators

'SEQUENTIAL PROTOCOL'
    cvx_begin SDP
    %cvx_solver mosek
    %cvx_precision best
    %cvx_precision high
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 2 copies
if k==2
    %Declare the SDP variable related to the probability p
    variable p
   % Declare the SDP variables related to S and F
    if isComplex==1
        variable S(d^6,d^6) complex semidefinite
        variable F(d^6,d^6) complex semidefinite
    else
        variable S(d^6,d^6) semidefinite
        variable F(d^6,d^6) semidefinite
    end
% Impose that the relation between input and output must be satisfied
% This is made exploiting the Choi isomorphism
    if g == 2
        for i=1:n_in
            PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i),k)) , eye(d^2)) ,[1 2 3 4],[d d d d d d]) == p*Jout(:,:,i);
        end
    end
    if g == 1
        % Perfect when gate 1 or gate 2 is the noisy gate.
        % Note: for this case, these conditions can be conbined into one equation. 
        for i=1:n_in
            PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4],[d d d d d d]) + PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4],[d d d d d d]) == 2*p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4],[d d d d d d]) == p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4],[d d d d d d]) == p*Jout(:,:,i);
        end
    end
    if g == 0
        PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4],[d d d d d d]) == p*Jout(:,:,1);
    end
    maximise p
    C=S+F;
    learning_is_sequential_protocol(C,d,k);  % make sure {S,F} forms a sequential learning comb
end %end if k==2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% case of 3 copies
if k==3
    %Declare the SDP variable related to the probability p
    variable p
   % Declare the SDP variables related to S and F
    if isComplex==1
        variable S(d^8,d^8) complex semidefinite
        variable F(d^8,d^8) complex semidefinite
    else
        variable S(d^8,d^8) semidefinite
        variable F(d^8,d^8) semidefinite
    end
% Impose that the relation between input and output must be satisfied
% This is made exploiting the Choi isomorphism
    if g == 3
        for i=1:n_in
            PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i),k)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,i);
        end
    end
    if g == 2
        for i=1:n_in
            PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), Jin(:,:,i), eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) +  PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), eye(d^2)/d, Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) + PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, Jin(:,:,i), Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == 3*p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), Jin(:,:,i), eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, Jin(:,:,i), Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), eye(d^2)/d, Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,i);
        end
    end
    if g == 1
        for i=1:n_in
            PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), eye(d^2)/d, eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) + PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, eye(d^2)/d, Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) + PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, Jin(:,:,i), eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == 3*p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(Jin(:,:,i), eye(d^2)/d, eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, Jin(:,:,i), eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,i);
            %PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, eye(d^2)/d, Jin(:,:,i))) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,i);
        end
    end
    if g == 0
        PartialTrace(S * Tensor(transpose(Tensor(eye(d^2)/d, eye(d^2)/d, eye(d^2)/d)) , eye(d^2)) ,[1 2 3 4 5 6],[d d d d d d d d]) == p*Jout(:,:,1);
    end
    maximise p
    C=S+F;
    learning_is_sequential_protocol(C,d,k);  % make sure {S,F} forms a sequential learning comb
end %end if k==3
%%%%%%%%%%%%%%%%%%%%%%%%
%finish SDP
    cvx_end
    maxp=p;
end